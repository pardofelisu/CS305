package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class ServerController{
	private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
	
	private static String checksum(String input) throws NoSuchAlgorithmException {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			byte[] encodehash = md.digest();
			return bytesToHex(encodehash);}
		catch (NoSuchAlgorithmException error) {
			error.printStackTrace();
		}
		return input;}
	
	public static String bytesToHex(byte[] bytes) {
		char[] hexChars = new char [bytes.length * 2];
		for (int i = 0; i < bytes.length; i++) {
			int v = bytes[i] & 0xFF;
			hexChars[i * 2] = HEX_ARRAY[v >>> 4];
			hexChars[i * 2 + 1] = HEX_ARRAY[v & 0x0F];
		}
		return new String(hexChars);
	}
	
	
    @RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException{
    	String data = "Hello Tashi Anderson!";
    	String checksumValue = checksum(data);
    	
        return "<p>data:"+data+" :SHA-256"+" : "+checksumValue+ "<p>";
    }
}

